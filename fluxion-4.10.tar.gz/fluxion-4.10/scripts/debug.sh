#!/usr/bin/env bash

# These are the debug flags used by the script
export FLUXIONDebug=1 
export FLUXIONWIKillProcesses=1 
export FLUXIONWIReloadDriver=1
